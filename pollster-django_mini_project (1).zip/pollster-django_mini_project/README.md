# Pollster App (Django project)

> Python Django app to create polls with questions/choices

## Quick Start
``` bash
cd pollster-django-crash
# Install dependencies
pip install pipenv

pipenv shell
# Install django
pipenv install django

cd pollster
# Serve on localhost:8000
python manage.py runserver
```
